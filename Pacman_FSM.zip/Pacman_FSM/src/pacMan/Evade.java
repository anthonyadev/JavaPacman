package pacMan;

public class Evade implements State{

		public int [][] map;
		public int pacX;
		public int pacY;
		public Ghost ghost;
		int moveX;
		int moveY;
		//constructs state
		public Evade(int[][] map, int pacX, int pacY, Ghost ghost)
		{
			this.map = map;
			this.pacX = pacX;
			this.pacY = pacY;
			this.ghost = ghost;
		}
		
		//updates based on pacmans position and chases
		public void Update()
		{
			if(pacX > ghost.ghostX)
			{
				moveX = -1;
			}
			
			if(pacX < ghost.ghostX)
			{
				moveX = 1;
			}
			
			if(pacY > ghost.ghostY)
			{
				moveY = -1;
			}
			
			if(pacY < ghost.ghostY)
			{
				moveY = 1;
			}
			
			
			if(map[ghost.ghostY][ghost.ghostRight] == 1)
			{
				ghost.canMoveRight = false;
			}
			else
			{
				ghost.canMoveRight = true;
			}
			
			if(map[ghost.ghostY][ghost.ghostLeft] == 1)
			{
				ghost.canMoveLeft = false;
			}
			else
			{
				ghost.canMoveLeft = true;
			}
			
			if(map[ghost.ghostTop][ghost.ghostX] == 1)
			{
				ghost.canMoveUp = false;
			}
			else
			{
				ghost.canMoveUp = true;
			}
			
			if(map[ghost.ghostBottom][ghost.ghostX] == 1)
			{
				ghost.canMoveDown = false;
			}
			else
			{
				ghost.canMoveDown = true;
			}
			
			if(moveX == 1 && ghost.canMoveRight)
			{
				ghost.ghostX += moveX;
			}
			
			if(moveX == -1 && ghost.canMoveLeft)
			{
				ghost.ghostX += moveX;
			}
				
			if(moveY == 1 && ghost.canMoveDown )
			{
				ghost.ghostY += moveY;
			}
			
			if(moveY == -1 && ghost.canMoveUp)
			{
				ghost.ghostY += moveY;
			}		
		}
	}