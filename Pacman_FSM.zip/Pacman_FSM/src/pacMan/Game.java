package pacMan;

public class Game {

		public static void main(String[] args) {
			
			 new GameFrame();
		}
	}

