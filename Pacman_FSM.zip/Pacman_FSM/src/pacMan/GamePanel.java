package pacMan;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener{
//properties
	static final int screenWidth = 1300;
	static final int screenHeight = 750;
	static final int size = 50;
	static final int GAME_UNITS = (screenWidth*screenHeight)/(size*size);
	static final int DELAY = 175;
	int pacManX = 5;
	int pacManY = 1;
	int moveX;
	int moveY;
	int num;
	int pacTop;
	int pacBottom;
	int pacRight;
	int pacLeft;
	Color ghostCol;
	int score;
	boolean chasing;
	int health = 3;
	boolean start;
	boolean canMoveUp = false;
	boolean canMoveDown = false;
	boolean canMoveLeft = false;
	boolean canMoveRight = false;
	
	public Ghost ghost = new Ghost();
	public State chase;
	public State evade;
	//MAP  0 = PELLET 1 = WALL 2 = EMPTY 3 = POWER PELLET
	public static int[][] pacMap = {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 3, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 2, 0, 2, 0, 0, 0, 2, 0, 2, 0, 2, 3, 1},
            {1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1},
            {1, 0, 0, 0, 2, 0, 2, 0, 1, 2, 0, 0, 2, 2, 0, 0, 2, 1, 0, 2, 0, 2, 0, 1, 0, 1},
            {1, 2, 1, 2, 1, 1, 1, 2, 1, 0, 1, 1, 2, 2, 1, 1, 0, 1, 2, 1, 1, 1, 2, 1, 2, 1},
            {1, 0, 0, 0, 2, 0, 1, 0, 1, 2, 1, 2, 0, 0, 2, 1, 2, 1, 0, 1, 0, 2, 0, 1, 0, 1},
            {1, 2, 1, 1, 1, 2, 1, 2, 1, 0, 1, 0, 2, 2, 0, 1, 0, 1, 2, 1, 2, 1, 1, 1, 2, 1},
            {1, 0, 2, 0, 2, 0, 2, 0, 1, 2, 1, 2, 0, 0, 2, 1, 2, 1, 0, 2, 0, 2, 0, 2, 0, 1},
            {1, 2, 1, 1, 1, 2, 1, 2, 1, 0, 1, 1, 2, 2, 1, 1, 0, 1, 2, 1, 2, 1, 1, 1, 2, 1},
            {1, 0, 1, 0, 2, 0, 1, 0, 1, 2, 0, 2, 0, 0, 2, 0, 2, 1, 0, 1, 0, 2, 0, 1, 0, 1},
            {1, 2, 1, 2, 1, 1, 1, 2, 1, 0, 1, 1, 2, 2, 1, 1, 0, 1, 2, 1, 1, 1, 2, 1, 2, 1},
            {1, 0, 0, 0, 1, 0, 2, 0, 1, 2, 1, 2, 0, 0, 2, 1, 2, 1, 0, 2, 0, 1, 0, 0, 0, 1},
            {1, 2, 1, 2, 1, 2, 1, 1, 1, 0, 1, 0, 2, 2, 0, 1, 0, 1, 1, 1, 2, 1, 2, 1, 2, 1},
            {1, 3, 2, 0, 2, 0, 2, 0, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 0, 2, 0, 2, 0, 2, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
    };

	boolean running = false;
	Timer timer;
	Random random;
	
	GamePanel(){
		random = new Random();
		this.setPreferredSize(new Dimension(screenWidth,screenHeight));
		this.setBackground(Color.black);
		this.setFocusable(true);
		this.addKeyListener(new MyKeyAdapter());
		
		
	}
	
	
	
	
	//initializes game
	public void startGame() {
		running = true;
		timer = new Timer(DELAY,this);
		timer.start();
		start = true;
		
	}
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		draw(g);
	}
	
	
	
	//draws individual objects
	public void draw(Graphics g) {
		
		if(running) {
			DRAW2(g);
			
			ghost.Draw(g);
			
			g.setColor(Color.yellow);
			g.fillRoundRect(pacManX * size, pacManY * size, size, size, size, size);
			
			
		}
		else {
			g.setColor(Color.red);
			g.setFont( new Font("Ink Free",Font.BOLD, 15));
			FontMetrics metrics2 = getFontMetrics(g.getFont());
			g.drawString("INSTRUCTIONS: WASD TO MOVE\tAVOID GHOSTS\tCOLLECT ALL PELLETS    SPACE TO START", (screenWidth - metrics2.stringWidth("INSTRUCTIONS: WASD TO MOVE    AVOID GHOSTS   COLLECT ALL PELLETS'"))/2, screenHeight/2);
			if(start)
			{
				gameOver(g);
			}
			
		}
	}
	
	//draws map
	public void DRAW2(Graphics g)
	{
		for(int i = 0; i < screenHeight / size; i++)
		{
			for(int j = 0; j < screenWidth / size; j++)
			{     
				if(pacMap[i][j] == 1)
				{
					g.setColor(Color.blue
);
					g.fillRect(j * size, i * size, size, size);
				}
				if(pacMap[i][j] == 0)
				{
					g.setColor(Color.white);
					g.fillRoundRect(j * size, i * size, size, size, size, size);
				}
				if(pacMap[i][j] == 3)
				{
					g.setColor(Color.orange);
					g.fillRoundRect(j * size, i * size, size, size, size, size);
				}
			}
		}
	}
	
	//checks position against pellet pos
	void CheckTouchingPellet()
	{
		
		for(int i = 0; i < screenHeight/size; i++)
		{
			for(int j = 0; j < screenWidth / size; j++)
			{
				if(pacMap[i][j] == 0 && pacManX == j && pacManY == i)
				{
					pacMap[i][j] = 2;
					score++;
				}
				
				if(pacMap[i][j] == 3 && pacManX == j && pacManY == i)
				{
					pacMap[i][j] = 2;
					score++;
					chasing = false;
					num = 50;
				}
			}
		}
	}
	
//checks if player can move relative to locations
	void CheckCollisions()
	{
		if(pacMap[pacManY][pacRight] == 1)
		{
			canMoveRight = false;
		}
		else
		{
			canMoveRight = true;
		}
		
		if(pacMap[pacManY][pacLeft] == 1)
		{
			canMoveLeft = false;
		}
		else
		{
			canMoveLeft = true;
		}
		
		if(pacMap[pacTop][pacManX] == 1)
		{
			canMoveUp = false;
		}
		else
		{
			canMoveUp = true;
		}
		
		if(pacMap[pacBottom][pacManX] == 1)
		{
			canMoveDown = false;
		}
		else
		{
			canMoveDown = true;
		}
	
	}
	
	
	
	
	
	//moves player based on location and input
	public void move()
	{
		
		if(moveX == 1 && canMoveRight)
		{
			pacManX += moveX;
		}
		
		if(moveX == -1 && canMoveLeft)
		{
			pacManX += moveX;
		}
			
		if(moveY == 1 && canMoveDown )
		{
			pacManY += moveY;
		}
		
		if(moveY == -1 && canMoveUp)
		{
			pacManY += moveY;
		}
		
		pacRight = pacManX + 1;
		pacLeft = pacManX - 1;
		pacTop = pacManY - 1;
		pacBottom = pacManY + 1;
		
	}
	
	//draws gameover text
	public void gameOver(Graphics g) {
		//Score
		g.setColor(Color.red);
		g.setFont( new Font("Ink Free",Font.BOLD, 40));
		FontMetrics metrics1 = getFontMetrics(g.getFont());
		g.drawString("Score: " + score, (screenWidth - metrics1.stringWidth("Score: " + score))/2, g.getFont().getSize());
		//Game Over text
		g.setColor(Color.red);
		g.setFont( new Font("Ink Free",Font.BOLD, 75));
		FontMetrics metrics2 = getFontMetrics(g.getFont());
		g.drawString("Game Over", (screenWidth - metrics2.stringWidth("Game Over"))/2, screenHeight/2);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		//main loop, like Update in unity
		if(running) {
			if(chasing)
			{
				chase = new Chase(pacMap, pacManX, pacManY, ghost);
				ghost.setState(chase);
			}
			else
			{
				evade = new Evade(pacMap, pacManX, pacManY, ghost);
				ghost.setState(evade);
			}
			
			if(score == 95)
			{
				running = false;
			}
			
			if(ghost.ghostX == pacManX && ghost.ghostY == pacManY)
			{
				health--;
			}
			
			if(health <= 0)
			{
				running = false;
			}
			
			num -= 1;
			
			if(num <= 0)
			{
				chasing = true;
			}
			
			
			ghost.Update();
			move();
			CheckCollisions();
			CheckTouchingPellet();
			
		}
		
		repaint();
	}
	//checks key inputs
	public class MyKeyAdapter extends KeyAdapter{
		@Override
		public void keyPressed(KeyEvent e) {
			switch(e.getKeyCode()) {
			case KeyEvent.VK_LEFT:
				moveX = -1;
				moveY = 0;
				break;
			case KeyEvent.VK_RIGHT:
				moveX = 1;
				moveY = 0;
				break;
			case KeyEvent.VK_UP:
				moveY = -1;
				moveX = 0;
				break;
			case KeyEvent.VK_DOWN:
				moveY = 1;
				moveX = 0;
				break;
			case KeyEvent.VK_SPACE:
				startGame();
			}
		}
	}
}
