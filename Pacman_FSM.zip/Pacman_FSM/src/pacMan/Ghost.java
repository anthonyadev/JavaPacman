package pacMan;
import java.awt.*;
public class Ghost {
	//properties
	State state;
	int ghostX = 15;
	int ghostY = 5;	
	
	boolean canMoveRight;
	boolean canMoveLeft;
	boolean canMoveUp;
	boolean canMoveDown;
	
	int ghostRight;
	int ghostLeft;
	int ghostTop;
	int ghostBottom;
	
	public Ghost()
	{
	}
	//sets and gets state
	public State getState()
	{
		return state;
	}
	
	public void setState(State state)
	{
		this.state = state;
	}
	//updates position and checks boundaries
	public void Update()
	{
		 state.Update();
		 ghostRight = ghostX + 1;
		 ghostLeft = ghostX - 1;
		 ghostTop = ghostY - 1;
		 ghostBottom = ghostY + 1;
		 System.out.println(ghostX);
		 System.out.println(ghostY);
		
	}
	//draws ghost
	public void Draw(Graphics g)
	{
		g.setColor(Color.red);
		g.fillRect(ghostX * 50, ghostY * 50, 50, 50);
	}
	
}
