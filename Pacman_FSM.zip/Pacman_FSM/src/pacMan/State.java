package pacMan;

public interface State {
	
	public void Update();
}
